import { Capacitor } from '@capacitor/core';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { CapacitorAudioRecorder } from '@capgo/capacitor-audio-recorder';

const isNative = () => Capacitor.isNativePlatform();

async function speak(text, rate = 1) {
  if (!isNative()) throw new Error('NATIVE_REQUIRED');
  // 每次重新播放时停止上一段，避免叠音。
  try { await TextToSpeech.stop(); } catch (_) {}
  await TextToSpeech.speak({
    text: String(text), lang: 'en-US', rate: Number(rate) || 1,
    pitch: 1, volume: 1, queueStrategy: 0
  });
}

async function recognize() {
  // Disabled in V3.2 because initiating the native plugin crashes certain realme
  // Android devices after permission is granted. Do not call requestPermissions,
  // available(), or start() until we have a device crash log and a verified fix.
  throw new Error('NATIVE_STT_DISABLED_USE_KEYBOARD_DICTATION');
}

let recording=false;
async function startRecording(){
  if(!isNative())throw new Error('NATIVE_REQUIRED');
  let permission=await CapacitorAudioRecorder.checkPermissions();
  if(permission.recordAudio!=='granted')permission=await CapacitorAudioRecorder.requestPermissions();
  if(permission.recordAudio!=='granted')throw new Error('MIC_PERMISSION_DENIED');
  await CapacitorAudioRecorder.startRecording();
  recording=true;
}
async function stopRecording(){
  if(!recording)throw new Error('NO_ACTIVE_RECORDING');
  const result=await CapacitorAudioRecorder.stopRecording();
  recording=false;
  if(!result.uri)throw new Error('RECORDING_URI_MISSING');
  return Capacitor.convertFileSrc(result.uri);
}
window.LinguaGoVoice = {isNative,speak,recognize,startRecording,stopRecording};
