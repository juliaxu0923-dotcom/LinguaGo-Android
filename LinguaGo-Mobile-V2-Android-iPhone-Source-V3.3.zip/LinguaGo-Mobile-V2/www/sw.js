// v2.7: Pages deployment updates replace the shell without clearing study records.
const CACHE='linguago-mobile-v3.3-password-safe-mic';
const FILES=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png','./bundled-library.js','./offline-audio-map.js','./native-voice.js','./cloud-sync.js','./cloud-config.js'];
self.addEventListener('install',event=>event.waitUntil(
  caches.open(CACHE).then(c=>c.addAll(FILES)).then(()=>self.skipWaiting())
));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  for(const name of await caches.keys()){
    if(name.startsWith('linguago-')&&name!==CACHE)await caches.delete(name);
  }
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const req=event.request,url=new URL(req.url);
  if(req.method!=='GET'||url.origin!==self.location.origin)return;
  if(req.mode==='navigate'){
    event.respondWith((async()=>{
      try{const fresh=await fetch(req,{cache:'no-store'});if(fresh.ok){const cache=await caches.open(CACHE);await cache.put('./index.html',fresh.clone());}return fresh;}
      catch(e){return await caches.match('./index.html')||Response.error();}
    })());
    return;
  }
  event.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const cached=await cache.match(req);
    if(cached)return cached;
    try{const fresh=await fetch(req);if(fresh.ok)await cache.put(req,fresh.clone());return fresh;}
    catch(e){return Response.error();}
  })());
});
