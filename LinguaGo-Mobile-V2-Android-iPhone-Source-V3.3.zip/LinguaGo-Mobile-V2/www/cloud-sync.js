/* LinguaGo cloud sync: uses Supabase Auth + RLS-protected PostgREST. */
(function () {
  'use strict';
  const cfg = window.LINGUAGO_CLOUD || {};
  const app = window.LinguaGoBridge;
  if (!app) { console.warn('LinguaGo sync bridge not found'); return; }
  const url = String(cfg.url || '').replace(/\/$/, '');
  const key = String(cfg.key || '');
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url) && !!key;
  const SESSION_KEY = 'linguago-sync-session-v1';
  const OWNER_KEY = 'linguago-sync-owner-v1';
  const BASE_PREFIX = 'linguago-sync-base-v1-';
  let session = null, timer = null, working = false, rerun = false, busy = false;
  let lastSync = '', message = '';

  const root = document.createElement('section');
  root.id = 'linguago-account-layer';
  root.innerHTML = `<style>
  #linguago-account-open{display:none!important}
  #linguago-account-backdrop{position:fixed;inset:0;z-index:20001;display:none;align-items:center;justify-content:center;background:#17172abb;padding:max(16px,env(safe-area-inset-top)) 14px max(16px,env(safe-area-inset-bottom));overflow:auto}
  #linguago-account-panel{box-sizing:border-box;max-height:min(86dvh,760px);overflow:auto;overscroll-behavior:contain;width:min(430px,100%);background:white;color:#1f2030;border-radius:20px;padding:18px;font:15px/1.6 system-ui,sans-serif;-webkit-overflow-scrolling:touch}
  #linguago-account-panel input{box-sizing:border-box;width:100%;padding:10px;border:1px solid #bbb;border-radius:8px;margin:7px 0;font:inherit}
  #linguago-account-panel button{border:0;border-radius:11px;margin:5px 6px 5px 0;padding:11px 13px;min-height:45px;background:#5545b5;color:white;font:inherit;touch-action:manipulation}
  #linguago-account-panel button.secondary{background:#eae9ee;color:#252439}
  #linguago-account-panel button:disabled{opacity:.6}
  #linguago-account-msg{font-size:13px;white-space:pre-wrap;color:#444;line-height:1.65}
  #linguago-account-panel input{min-height:48px;font-size:16px}
  #linguago-account-layer [hidden]{display:none!important}
  #linguago-account-form{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  #linguago-account-form input{grid-column:1/-1;margin:2px 0}
  #linguago-account-form button{margin:0;width:100%}
  #linguago-account-close{min-width:72px;flex:none}
  @media(max-width:390px){#linguago-account-panel{padding:15px}#linguago-account-form{gap:6px}}
  @media(max-height:650px){#linguago-account-panel{max-height:80dvh}#linguago-account-backdrop{align-items:flex-start}}
  </style>
  <button id="linguago-account-open" type="button">☁️ 账号同步</button>
  <div id="linguago-account-backdrop" role="dialog" aria-modal="true" aria-label="账号同步">
    <div id="linguago-account-panel">
      <div style="display:flex;justify-content:space-between;align-items:center"><strong>☁️ LinguaGo 学习记录同步</strong><button class="secondary" id="linguago-account-close" type="button">关闭</button></div>
      <p id="linguago-account-status"></p>
      <div id="linguago-account-form">
        <label style="grid-column:1/-1">邮箱账号<input id="linguago-account-email" type="email" placeholder="请输入邮箱账号" autocomplete="email" inputmode="email" maxlength="254"></label>
        <label style="grid-column:1/-1">密码（新注册至少 8 位）<input id="linguago-account-password" type="password" placeholder="请输入密码" autocomplete="current-password" minlength="8" maxlength="72"></label>
        <label style="grid-column:1/-1;font-size:13px;display:flex;align-items:center;gap:8px"><input id="linguago-account-show-password" type="checkbox" style="width:18px;min-height:18px;margin:0">显示密码</label>
        <button id="linguago-account-login" type="button">🔐 登录并同步</button>
        <button id="linguago-account-register" class="secondary" type="button">注册新账号</button>
        <div style="grid-column:1/-1;font-size:12px;color:#666">新用户先点「注册新账号」；已有密码的用户直接登录。无需发送邮箱验证码。旧的仅验证码账号若没有设置过密码，需要先完成一次密码设置。</div>
      </div>
      <div id="linguago-account-controls" hidden>
        <button id="linguago-account-sync" type="button">立即同步</button><button id="linguago-account-logout" class="secondary" type="button">退出登录</button>
        <div style="border-top:1px solid #eee;margin-top:10px;padding-top:10px"><strong>设置或修改登录密码</strong><p style="font-size:12px;color:#666;margin:4px 0">如果之前用过邮箱验证码登录，趁账号仍处于登录状态，现在就能设置密码，以后直接密码登录。</p>
          <input id="linguago-account-new-password" type="password" placeholder="新密码，至少 8 位" autocomplete="new-password" minlength="8" maxlength="72">
          <button id="linguago-account-change-password" type="button" class="secondary">保存新密码</button>
        </div>
      </div>
      <div style="border-top:1px solid #eee;margin-top:12px;padding-top:12px"><strong>学习记录备份</strong><br><button id="linguago-account-export" class="secondary" type="button">⬇️ 导出本机学习记录</button><button id="linguago-account-import" class="secondary" type="button">⬆️ 从文件恢复</button><input id="linguago-account-file" type="file" accept="application/json,.json" hidden></div>
      <p id="linguago-account-msg" aria-live="polite"></p>
      <p style="font-size:12px;color:#666">登录后，本机已掌握单词、学习进度、听力和口语记录会上传到你的云账号。断网时仍保留本机数据。首次同步成功前请勿卸载旧 App 或清除浏览器数据。</p>
    </div>
  </div>`;
  document.body.appendChild(root);
  const $ = id => document.getElementById('linguago-account-' + id);
  function tell(s) { message = s || ''; $('msg').textContent = message; }
  function draw() {
    $('form').hidden = !configured || !!session;
    $('controls').hidden = !configured || !session;
    $('status').textContent = !configured ? '云端尚未配置。本机学习记录正常保留。' : session ? '已登录：' + (session.user.email || '账号') + (lastSync ? '　最近同步：' + lastSync : '　等待同步') : '未登录：记录保存在当前设备。';
    $('open').textContent = session ? '☁️ 已登录' : '☁️ 账号同步';
    ['login', 'register', 'sync', 'logout', 'change-password'].forEach(id => { $(id).disabled = busy; });
    $('msg').textContent = message;
  }
  function showAccount() { $('backdrop').style.display = 'flex'; draw(); }
  function closeAccount() { $('backdrop').style.display = 'none'; }
  $('open').onclick = showAccount;
  document.addEventListener('click', e => { if (e.target.closest('[data-open-linguago-account]')) { e.preventDefault(); showAccount(); } });
  $('close').onclick = closeAccount;
  $('backdrop').onclick = e => { if (e.target === $('backdrop')) closeAccount(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('backdrop').style.display === 'flex') closeAccount(); });
  $('panel').addEventListener('focusin', e => { if (e.target.matches('input')) setTimeout(() => e.target.scrollIntoView({ block: 'nearest', behavior: 'smooth' }), 180); });
  function storeSession(value) {
    session = value;
    try { if (value) localStorage.setItem(SESSION_KEY, JSON.stringify(value)); else localStorage.removeItem(SESSION_KEY); } catch (_) {}
    draw();
  }
  function parseJson(key) { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (_) { return null; } }
  const list = x => Array.isArray(x) ? x : [];
  const uniq = x => Array.from(new Set(x));
  function reconcileSet(local, remote, previous) {
    const left = new Set(list(local)), right = new Set(list(remote));
    if (!previous) return uniq([...left, ...right]);
    const before = new Set(list(previous));
    // Three-way merge: local additions and intentional local removals win;
    // other-device additions since the last baseline are preserved.
    before.forEach(x => { if (!left.has(x)) right.delete(x); });
    left.forEach(x => { if (!before.has(x)) right.add(x); });
    return [...right];
  }
  function merge(local, remote, previous) {
    local = local || {}; remote = remote || {}; previous = previous || null;
    const result = Object.assign({}, local, remote);
    ['known', 'heard', 'days'].forEach(k => {
      result[k] = reconcileSet(local[k], remote[k], previous && previous[k]);
    });
    result.spoken = Math.max(Number(local.spoken) || 0, Number(remote.spoken) || 0);
    result.masteredDates = Object.assign({}, remote.masteredDates || {}, local.masteredDates || {});
    Object.keys(result.masteredDates).forEach(k => { if (!result.known.includes(k)) delete result.masteredDates[k]; });
    const today = new Date().toLocaleDateString('sv-SE');
    const dayL = local.daily && local.daily.date === today ? local.daily : {};
    const dayR = remote.daily && remote.daily.date === today ? remote.daily : {};
    result.daily = { date: today, known: uniq([...list(dayL.known), ...list(dayR.known)]), heard: uniq([...list(dayL.heard), ...list(dayR.heard)]), spoken: Math.max(Number(dayL.spoken) || 0, Number(dayR.spoken) || 0) };
    result.wordPractice = Object.assign({}, remote.wordPractice || {}, local.wordPractice || {});
    const custom = new Map();
    [...list(remote.customWords), ...list(local.customWords)].forEach(w => { if (w && typeof w.w === 'string') custom.set(w.w.toLowerCase(), w); });
    result.customWords = [...custom.values()];
    const archived = new Map();
    [...list(remote.speakingArchives), ...list(local.speakingArchives)].forEach(s => { if (s && s.id) archived.set(s.id, s); });
    result.speakingArchives = [...archived.values()].slice(-30);
    // The currently open conversation is preserved as well as past archives.
    result.chatHistory = list(local.chatHistory).length ? list(local.chatHistory).slice(-100) : list(remote.chatHistory).slice(-100);
    return result;
  }
  async function call(path, method, body, prefer) {
    const headers = { apikey: key, 'Content-Type': 'application/json' };
    if (session && session.access_token && !path.startsWith('/auth/v1/token') && !path.startsWith('/auth/v1/signup')) headers.Authorization = 'Bearer ' + session.access_token;
    if (prefer) headers.Prefer = prefer;
    const res = await fetch(url + path, { method: method || 'GET', headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await res.text(); let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) {}
    if (!res.ok) throw new Error(data && (data.msg || data.message || data.error_description || data.error) || 'HTTP ' + res.status);
    return data;
  }
  async function ensureToken() {
    if (!session) return false;
    if (Date.now() < (Number(session.expires_at) || 0) - 120000) return true;
    try {
      const s = await call('/auth/v1/token?grant_type=refresh_token', 'POST', { refresh_token: session.refresh_token });
      if (!s || !s.access_token || !s.user) throw new Error('expired');
      storeSession(Object.assign({}, s, { expires_at: Date.now() + Number(s.expires_in || 3600) * 1000 }));
      return true;
    } catch (_) { storeSession(null); tell('登录已失效，请重新登录。'); return false; }
  }
  async function pull() {
    const rows = await call('/rest/v1/learning_progress?select=payload&user_id=eq.' + encodeURIComponent(session.user.id) + '&limit=1');
    return Array.isArray(rows) && rows.length ? rows[0].payload : null;
  }
  async function push(data) {
    await call('/rest/v1/learning_progress?on_conflict=user_id', 'POST', { user_id: session.user.id, payload: data, updated_at: new Date().toISOString() }, 'resolution=merge-duplicates,return=minimal');
  }
  async function synchronize() {
    if (!configured || !session) return;
    if (working) { rerun = true; return; }
    working = true;
    try {
      if (!navigator.onLine) throw new Error('设备离线，联网后重试');
      if (!await ensureToken()) return;
      const oldOwner = localStorage.getItem(OWNER_KEY);
      if (oldOwner && oldOwner !== session.user.id) {
        throw new Error('本设备上次同步了另一账号。为防止学习记录串号，建议退出并登录原账号；切换账号前请先导出本机备份，勿清除应用数据。');
      }
      const sameUser = true;
      const local = sameUser ? app.snapshot() : {};
      const remote = await pull();
      const base = sameUser ? parseJson(BASE_PREFIX + session.user.id) : null;
      const final = remote ? merge(local, remote, base) : local;
      // Do not remove local records until remote write succeeds.
      await push(final);
      app.restore(final);
      localStorage.setItem(BASE_PREFIX + session.user.id, JSON.stringify(final));
      localStorage.setItem(OWNER_KEY, session.user.id);
      lastSync = new Date().toLocaleString('zh-CN');
      tell('✅ 学习记录已同步到云端。');
    } catch (e) {
      tell('同步失败：' + String(e.message || e) + '。记录仍在本机，请不要卸载。');
    } finally {
      working = false; draw();
      if (rerun) { rerun = false; setTimeout(synchronize, 1000); }
    }
  }
  window.LinguaGoCloud = { scheduleSave() { if (!session) return; clearTimeout(timer); timer = setTimeout(synchronize, 1800); }, sync: synchronize };
  function readableAuthError(raw) {
    const s = String(raw || '');
    if (/email not confirmed|email_not_confirmed/i.test(s))
      return '此账号仍被 Supabase 要求验证邮箱。请管理员到 Authentication → Providers → Email 关闭 Confirm email；旧账号可能还需完成一次验证或重设密码。';
    if (/invalid login credentials|invalid_credentials/i.test(s))
      return '邮箱或密码不正确。如果以前只用验证码登录，请先为旧账号设置密码，不能直接用新密码登录。';
    if (/user already registered|user_already_exists|already been registered/i.test(s))
      return '这个邮箱已注册。请直接登录；如果之前用验证码注册，需先为旧账号设置密码。';
    if (/password.*short|weak_password|at least|password.*length/i.test(s))
      return '密码不符合要求。请设置至少 8 位，并尽量混合字母、数字和符号。';
    if (/rate limit|too many requests|over_request_rate_limit/i.test(s))
      return '操作过于频繁，请稍后再试。';
    if (/failed to fetch|networkerror|network request failed/i.test(s))
      return '无法连接 Supabase，请检查网络。学习记录仍保存在本机。';
    return '操作失败：' + s.slice(0, 220);
  }
  function getCredentials(isRegistration) {
    const email = $('email').value.trim().toLowerCase();
    const password = $('password').value;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw Error('请输入有效的邮箱账号。');
    if (password.length < (isRegistration ? 8 : 6)) throw Error(isRegistration ? '注册密码至少需要 8 位。' : '请输入有效密码（至少 6 位）。');
    return { email, password };
  }
  function saveAuthSession(data) {
    if (!data || !data.access_token || !data.refresh_token || !data.user || !data.user.id) return false;
    storeSession(Object.assign({}, data, { expires_at: Date.now() + Number(data.expires_in || 3600) * 1000 }));
    // Never retain the password after successful login. Only the Supabase session is stored.
    $('password').value = '';
    return true;
  }
  async function loginPassword() {
    if (!configured || busy) return;
    let credentials;
    try { credentials = getCredentials(false); } catch (e) { tell(e.message); return; }
    busy = true; draw();
    try {
      const data = await call('/auth/v1/token?grant_type=password', 'POST', credentials);
      if (!saveAuthSession(data)) throw Error('服务端没有返回登录会话，请检查账号配置。');
      tell('✅ 密码登录成功，正在同步学习记录…');
      await synchronize();
    } catch (e) { tell(readableAuthError(e.message || e)); }
    finally { busy = false; draw(); }
  }
  async function registerPassword() {
    if (!configured || busy) return;
    let credentials;
    try { credentials = getCredentials(true); } catch (e) { tell(e.message); return; }
    if (!confirm('使用该邮箱和密码注册 LinguaGo 账号？\n请使用自己的邮箱和强密码。')) return;
    busy = true; draw();
    try {
      const data = await call('/auth/v1/signup', 'POST', credentials);
      if (!saveAuthSession(data)) {
        // When Supabase email confirmation is enabled, signUp returns a user but no session.
        // Do not claim cloud sync has succeeded, and do not clear the local records.
        try {
          const loggedIn = await call('/auth/v1/token?grant_type=password', 'POST', credentials);
          if (saveAuthSession(loggedIn)) {
            tell('✅ 注册及登录成功，正在同步学习记录…');
            await synchronize();
            return;
          }
        } catch (e) {
          if (/email not confirmed|email_not_confirmed/i.test(String(e.message || e))) {
            tell('注册请求已提交，但 Supabase 仍要求验证邮箱，暂时不能直接登录。请管理员到 Authentication → Providers → Email 关闭 Confirm email。学习记录仍在本机。');
            return;
          }
          throw e;
        }
        tell('注册请求已提交，但没有取得登录会话。请确认 Supabase 已关闭 Confirm email；本机记录没有被清除。');
        return;
      }
      tell('✅ 注册及登录成功，正在同步学习记录…');
      await synchronize();
    } catch (e) { tell(readableAuthError(e.message || e)); }
    finally { busy = false; draw(); }
  }
  async function changePassword() {
    if (!session || busy) return;
    const password = $('new-password').value;
    if (password.length < 8) { tell('新密码至少 8 位。'); return; }
    if (!confirm('为当前登录的 LinguaGo 账号设置这个新密码？')) return;
    busy = true; draw();
    try {
      if (!await ensureToken()) return;
      await call('/auth/v1/user', 'PUT', { password });
      $('new-password').value = '';
      tell('✅ 已设置账号密码，以后可以直接使用邮箱和密码登录。');
    } catch (e) { tell(readableAuthError(e.message || e)); }
    finally { busy = false; draw(); }
  }
  // Local export remains available before registration and when the cloud is down.
  $('export').onclick = () => {
    try {
      const record = {type:'linguago-learning-backup',version:1,createdAt:new Date().toISOString(),progress:app.snapshot()};
      const blob = new Blob([JSON.stringify(record,null,2)],{type:'application/json'});
      const ref = URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=ref;a.download='LinguaGo-学习记录-'+new Date().toISOString().slice(0,10)+'.json';
      document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(ref),30000);
      tell('已准备备份文件。如果手机没有弹出保存提示，请改用浏览器打开网页导出。');
    }catch(e){tell('备份失败：'+String(e.message||e));}
  };
  $('import').onclick=()=>{$('file').click();};
  $('file').onchange=async e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    try{
      if(file.size>2*1024*1024)throw Error('备份文件过大');
      const b=JSON.parse(await file.text());
      if(b.type!=='linguago-learning-backup'||!b.progress||!Array.isArray(b.progress.known))throw Error('不是有效的 LinguaGo 备份');
      if(!confirm('将备份中的记录与当前记录合并，再自动同步到当前登录账号。确认继续吗？'))return;
      const current=app.snapshot();const data=merge(current,b.progress,null);
      app.restore(data);if(session) await synchronize();
      tell('已恢复并合并备份记录。'+(session?'如网络正常，将继续同步。':'登录后可上传云端。'));
    }catch(err){tell('恢复失败：'+String(err.message||err));}
    finally{$('file').value='';}
  };
  $('change-password').onclick = changePassword;
  $('login').onclick = loginPassword;
  $('register').onclick = registerPassword;
  $('password').addEventListener('keydown', e => { if (e.key === 'Enter') loginPassword(); });
  $('show-password').addEventListener('change', e => { $('password').type = e.target.checked ? 'text' : 'password'; });
  $('sync').onclick = () => synchronize();
  $('logout').onclick = async () => {
    if (!confirm('退出账号将停止自动同步，但本机记录仍会保留。确定吗？')) return;
    try { await call('/auth/v1/logout', 'POST'); } catch (_) {}
    storeSession(null); tell('已退出，学习记录仍保留在本机。');
  };
  addEventListener('online', () => { if (session) synchronize(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && session) synchronize(); });
  if (configured) {
    const prior = parseJson(SESSION_KEY);
    if (prior && prior.access_token && prior.user && prior.user.id) { session = prior; synchronize(); }
  }
  draw();
})();
