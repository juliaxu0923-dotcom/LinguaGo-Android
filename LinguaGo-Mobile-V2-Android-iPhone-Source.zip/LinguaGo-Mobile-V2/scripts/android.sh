#!/usr/bin/env bash
set -euo pipefail
npm install
if [ ! -d android ]; then npx cap add android; fi
npx capacitor-assets generate --android
npx cap sync android
(cd android && bash ./gradlew assembleDebug)
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
