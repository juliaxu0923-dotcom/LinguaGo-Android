import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const file = resolve(process.cwd(), 'node_modules/@capgo/capacitor-speech-recognition/android/src/main/AndroidManifest.xml');
if (!existsSync(file)) { console.warn('[LinguaGo] Speech recognition plugin manifest unavailable; Android may need manual manifest setup'); process.exit(0); }
let xml=readFileSync(file,'utf8');
if(!xml.includes('android.speech.RecognitionService')) {
  if(!xml.includes('</manifest>')) throw new Error('Unexpected recognizer manifest format');
  xml=xml.replace('</manifest>', `    <!-- Android 11+: allow SpeechRecognizer to discover installed recognition services -->
    <queries>
      <intent><action android:name="android.speech.RecognitionService" /></intent>
    </queries>
</manifest>`);
  writeFileSync(file,xml);
}
if(!xml.includes('android.speech.RecognitionService'))throw Error('Speech recognizer package visibility was not configured');
console.log('[LinguaGo] Android speech recognizer query installed');
