// 浏览器预览使用 HTML Web Speech API；安卓构建时通过 esbuild 替换为 Capacitor 原生桥接代码。
window.LinguaGoVoice={isNative:()=>false};
