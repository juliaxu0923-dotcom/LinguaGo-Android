/* LinguaGo cloud sync: uses Supabase Auth + RLS-protected PostgREST. */
(function () {
  'use strict';
  const cfg = window.LINGUAGO_CLOUD || {};
  const app = window.LinguaGoBridge;
  if (!app) { console.warn('LinguaGo sync bridge not found'); return; }
  const url = String(cfg.url || '').replace(/\/$/, '');
  const key = String(cfg.key || '');
  const configured = /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(url) && !!key;
  const SESSION_KEY = 'linguago-sync-session-v1';
  const OWNER_KEY = 'linguago-sync-owner-v1';
  const BASE_PREFIX = 'linguago-sync-base-v1-';
  let session = null, timer = null, working = false, rerun = false, busy = false;
  let lastSync = '', message = '';

  const root = document.createElement('section');
  root.id = 'linguago-account-layer';
  root.innerHTML = `<style>
  #linguago-account-open{display:none!important}
  #linguago-account-backdrop{position:fixed;inset:0;z-index:20001;display:none;align-items:center;justify-content:center;background:#17172abb;padding:max(16px,env(safe-area-inset-top)) 14px max(16px,env(safe-area-inset-bottom));overflow:auto}
  #linguago-account-panel{box-sizing:border-box;max-height:min(86dvh,760px);overflow:auto;overscroll-behavior:contain;width:min(430px,100%);background:white;color:#1f2030;border-radius:20px;padding:18px;font:15px/1.6 system-ui,sans-serif;-webkit-overflow-scrolling:touch}
  #linguago-account-panel input{box-sizing:border-box;width:100%;padding:10px;border:1px solid #bbb;border-radius:8px;margin:7px 0;font:inherit}
  #linguago-account-panel button{border:0;border-radius:11px;margin:5px 6px 5px 0;padding:11px 13px;min-height:45px;background:#5545b5;color:white;font:inherit;touch-action:manipulation}
  #linguago-account-panel button.secondary{background:#eae9ee;color:#252439}
  #linguago-account-panel button:disabled{opacity:.6}
  #linguago-account-msg{font-size:13px;white-space:pre-wrap;color:#444;line-height:1.65}
  #linguago-account-panel input{min-height:48px;font-size:16px}
  #linguago-account-form{display:grid;grid-template-columns:1fr 1fr;gap:8px}
  #linguago-account-form input{grid-column:1/-1;margin:2px 0}
  #linguago-account-form button{margin:0;width:100%}
  #linguago-account-close{min-width:72px;flex:none}
  @media(max-width:390px){#linguago-account-panel{padding:15px}#linguago-account-form{gap:6px}}
  @media(max-height:650px){#linguago-account-panel{max-height:80dvh}#linguago-account-backdrop{align-items:flex-start}}
  </style>
  <button id="linguago-account-open" type="button">☁️ 账号同步</button>
  <div id="linguago-account-backdrop" role="dialog" aria-modal="true" aria-label="账号同步">
    <div id="linguago-account-panel">
      <div style="display:flex;justify-content:space-between;align-items:center"><strong>☁️ LinguaGo 学习记录同步</strong><button class="secondary" id="linguago-account-close" type="button">关闭</button></div>
      <p id="linguago-account-status"></p>
      <div id="linguago-account-form"><input id="linguago-account-email" type="email" placeholder="邮箱" autocomplete="email"><input id="linguago-account-password" type="password" placeholder="密码（至少 6 位）" autocomplete="current-password"><button id="linguago-account-login" type="button">登录并同步</button><button id="linguago-account-register" class="secondary" type="button">注册</button></div>
      <div id="linguago-account-controls" hidden><button id="linguago-account-sync" type="button">立即同步</button><button id="linguago-account-logout" class="secondary" type="button">退出登录</button></div>
      <div style="border-top:1px solid #eee;margin-top:12px;padding-top:12px"><strong>学习记录备份</strong><br><button id="linguago-account-export" class="secondary" type="button">⬇️ 导出本机学习记录</button><button id="linguago-account-import" class="secondary" type="button">⬆️ 从文件恢复</button><input id="linguago-account-file" type="file" accept="application/json,.json" hidden></div>
      <p id="linguago-account-msg" aria-live="polite"></p>
      <p style="font-size:12px;color:#666">登录后，本机已掌握单词、学习进度、听力和口语记录会上传到你的云账号。断网时仍保留本机数据。首次同步成功前请勿卸载旧 App 或清除浏览器数据。</p>
    </div>
  </div>`;
  document.body.appendChild(root);
  const $ = id => document.getElementById('linguago-account-' + id);
  function tell(s) { message = s || ''; $('msg').textContent = message; }
  function draw() {
    $('form').hidden = !configured || !!session;
    $('controls').hidden = !configured || !session;
    $('status').textContent = !configured ? '云端尚未配置。本机学习记录正常保留。' : session ? '已登录：' + (session.user.email || '账号') + (lastSync ? '　最近同步：' + lastSync : '　等待同步') : '未登录：记录保存在当前设备。';
    $('open').textContent = session ? '☁️ 已登录' : '☁️ 账号同步';
    ['login', 'register', 'sync', 'logout'].forEach(id => { $(id).disabled = busy; });
    $('msg').textContent = message;
  }
  function showAccount() { $('backdrop').style.display = 'flex'; draw(); }
  function closeAccount() { $('backdrop').style.display = 'none'; }
  $('open').onclick = showAccount;
  document.addEventListener('click', e => { if (e.target.closest('[data-open-linguago-account]')) { e.preventDefault(); showAccount(); } });
  $('close').onclick = closeAccount;
  $('backdrop').onclick = e => { if (e.target === $('backdrop')) closeAccount(); };
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('backdrop').style.display === 'flex') closeAccount(); });
  $('panel').addEventListener('focusin', e => { if (e.target.matches('input')) setTimeout(() => e.target.scrollIntoView({ block: 'nearest', behavior: 'smooth' }), 180); });
  function storeSession(value) {
    session = value;
    try { if (value) localStorage.setItem(SESSION_KEY, JSON.stringify(value)); else localStorage.removeItem(SESSION_KEY); } catch (_) {}
    draw();
  }
  function parseJson(key) { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (_) { return null; } }
  const list = x => Array.isArray(x) ? x : [];
  const uniq = x => Array.from(new Set(x));
  function reconcileSet(local, remote, previous) {
    const left = new Set(list(local)), right = new Set(list(remote));
    if (!previous) return uniq([...left, ...right]);
    const before = new Set(list(previous));
    // Three-way merge: local additions and intentional local removals win;
    // other-device additions since the last baseline are preserved.
    before.forEach(x => { if (!left.has(x)) right.delete(x); });
    left.forEach(x => { if (!before.has(x)) right.add(x); });
    return [...right];
  }
  function merge(local, remote, previous) {
    local = local || {}; remote = remote || {}; previous = previous || null;
    const result = Object.assign({}, local, remote);
    ['known', 'heard', 'days'].forEach(k => {
      result[k] = reconcileSet(local[k], remote[k], previous && previous[k]);
    });
    result.spoken = Math.max(Number(local.spoken) || 0, Number(remote.spoken) || 0);
    result.masteredDates = Object.assign({}, remote.masteredDates || {}, local.masteredDates || {});
    Object.keys(result.masteredDates).forEach(k => { if (!result.known.includes(k)) delete result.masteredDates[k]; });
    const today = new Date().toLocaleDateString('sv-SE');
    const dayL = local.daily && local.daily.date === today ? local.daily : {};
    const dayR = remote.daily && remote.daily.date === today ? remote.daily : {};
    result.daily = { date: today, known: uniq([...list(dayL.known), ...list(dayR.known)]), heard: uniq([...list(dayL.heard), ...list(dayR.heard)]), spoken: Math.max(Number(dayL.spoken) || 0, Number(dayR.spoken) || 0) };
    result.wordPractice = Object.assign({}, remote.wordPractice || {}, local.wordPractice || {});
    const custom = new Map();
    [...list(remote.customWords), ...list(local.customWords)].forEach(w => { if (w && typeof w.w === 'string') custom.set(w.w.toLowerCase(), w); });
    result.customWords = [...custom.values()];
    const archived = new Map();
    [...list(remote.speakingArchives), ...list(local.speakingArchives)].forEach(s => { if (s && s.id) archived.set(s.id, s); });
    result.speakingArchives = [...archived.values()].slice(-30);
    // The currently open conversation is preserved as well as past archives.
    result.chatHistory = list(local.chatHistory).length ? list(local.chatHistory).slice(-100) : list(remote.chatHistory).slice(-100);
    return result;
  }
  async function call(path, method, body, prefer) {
    const headers = { apikey: key, 'Content-Type': 'application/json' };
    if (session && session.access_token && !path.startsWith('/auth/v1/token') && !path.startsWith('/auth/v1/signup')) headers.Authorization = 'Bearer ' + session.access_token;
    if (prefer) headers.Prefer = prefer;
    const res = await fetch(url + path, { method: method || 'GET', headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const text = await res.text(); let data = null;
    try { data = text ? JSON.parse(text) : null; } catch (_) {}
    if (!res.ok) throw new Error(data && (data.msg || data.message || data.error_description || data.error) || 'HTTP ' + res.status);
    return data;
  }
  async function ensureToken() {
    if (!session) return false;
    if (Date.now() < (Number(session.expires_at) || 0) - 120000) return true;
    try {
      const s = await call('/auth/v1/token?grant_type=refresh_token', 'POST', { refresh_token: session.refresh_token });
      if (!s || !s.access_token || !s.user) throw new Error('expired');
      storeSession(Object.assign({}, s, { expires_at: Date.now() + Number(s.expires_in || 3600) * 1000 }));
      return true;
    } catch (_) { storeSession(null); tell('登录已失效，请重新登录。'); return false; }
  }
  async function pull() {
    const rows = await call('/rest/v1/learning_progress?select=payload&user_id=eq.' + encodeURIComponent(session.user.id) + '&limit=1');
    return Array.isArray(rows) && rows.length ? rows[0].payload : null;
  }
  async function push(data) {
    await call('/rest/v1/learning_progress?on_conflict=user_id', 'POST', { user_id: session.user.id, payload: data, updated_at: new Date().toISOString() }, 'resolution=merge-duplicates,return=minimal');
  }
  async function synchronize() {
    if (!configured || !session) return;
    if (working) { rerun = true; return; }
    working = true;
    try {
      if (!navigator.onLine) throw new Error('设备离线，联网后重试');
      if (!await ensureToken()) return;
      const oldOwner = localStorage.getItem(OWNER_KEY);
      if (oldOwner && oldOwner !== session.user.id) {
        throw new Error('本设备上次同步了另一账号。为防止学习记录串号，建议退出并登录原账号；切换账号前请先导出本机备份，勿清除应用数据。');
      }
      const sameUser = true;
      const local = sameUser ? app.snapshot() : {};
      const remote = await pull();
      const base = sameUser ? parseJson(BASE_PREFIX + session.user.id) : null;
      const final = remote ? merge(local, remote, base) : local;
      // Do not remove local records until remote write succeeds.
      await push(final);
      app.restore(final);
      localStorage.setItem(BASE_PREFIX + session.user.id, JSON.stringify(final));
      localStorage.setItem(OWNER_KEY, session.user.id);
      lastSync = new Date().toLocaleString('zh-CN');
      tell('✅ 学习记录已同步到云端。');
    } catch (e) {
      tell('同步失败：' + String(e.message || e) + '。记录仍在本机，请不要卸载。');
    } finally {
      working = false; draw();
      if (rerun) { rerun = false; setTimeout(synchronize, 1000); }
    }
  }
  window.LinguaGoCloud = { scheduleSave() { if (!session) return; clearTimeout(timer); timer = setTimeout(synchronize, 1800); }, sync: synchronize };
  let registerCooldownUntil=0, cooldownTimer=null;
  function showCooldown() {
    const secs = Math.ceil((registerCooldownUntil - Date.now()) / 1000);
    if (secs > 0) { $('register').disabled = true; $('register').textContent = '等 ' + secs + ' 秒'; }
    else { $('register').disabled = busy; $('register').textContent = '注册'; clearInterval(cooldownTimer); cooldownTimer=null; }
  }
  function readableAuthError(raw, register) {
    const s=String(raw||'');
    const seconds=/(?:after|in)\s+(\d+)\s+seconds?/i.exec(s);
    if (seconds || /rate limit|too many requests|over_email_send_rate_limit/i.test(s)) {
      const n=seconds?Math.max(1,Number(seconds[1])):60;
      registerCooldownUntil=Date.now()+n*1000;
      if(!cooldownTimer)cooldownTimer=setInterval(showCooldown,1000);
      showCooldown();
      return '请求太频繁，请等约 '+n+' 秒再试。如果已注册过这个邮箱，请直接点「登录并同步」，不要重复注册。';
    }
    if (/email not confirmed|email_not_confirmed/i.test(s)) return '邮箱还没验证，请打开邮件中的验证链接，再回来登录。';
    if (/invalid login credentials|invalid_credentials/i.test(s)) return '邮箱或密码不正确。如果刚注册，请先完成邮箱验证。';
    if (/user already registered|already been registered/i.test(s)) return '邮箱已注册，请点击「登录并同步」，无需重复注册。';
    if (/failed to fetch|networkerror/i.test(s)) return '网络连接失败，请检查是否能访问 Supabase，再重试。';
    return (register?'注册':'登录')+'失败：'+s.slice(0,250);
  }
  async function authenticate(register) {
    if (!configured || busy) return;
    if (register && Date.now()<registerCooldownUntil) { showCooldown(); tell('注册请求冷却中，请稍后再试，已有账号可直接登录。'); return; }
    const email = $('email').value.trim(), password = $('password').value;
    if (!email || password.length < 6) { tell('请填写正确邮箱和至少六位密码。'); return; }
    busy = true; draw();
    try {
      const path = register ? '/auth/v1/signup' : '/auth/v1/token?grant_type=password';
      const result = await call(path, 'POST', { email, password });
      if (register && !result.access_token) { tell('注册成功，请先查收邮箱验证邮件，再回来登录。'); return; }
      if (!result.access_token || !result.user || !result.user.id) throw new Error('没有获得有效登录信息');
      storeSession(Object.assign({}, result, { expires_at: Date.now() + Number(result.expires_in || 3600) * 1000 }));
      $('password').value='';
      await synchronize();
    } catch (e) { tell(readableAuthError(e.message || e, register)); }
    finally { busy = false; draw(); showCooldown(); }
  }
  // Local export remains available before registration and when the cloud is down.
  $('export').onclick = () => {
    try {
      const record = {type:'linguago-learning-backup',version:1,createdAt:new Date().toISOString(),progress:app.snapshot()};
      const blob = new Blob([JSON.stringify(record,null,2)],{type:'application/json'});
      const ref = URL.createObjectURL(blob);
      const a=document.createElement('a');a.href=ref;a.download='LinguaGo-学习记录-'+new Date().toISOString().slice(0,10)+'.json';
      document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(ref),30000);
      tell('已准备备份文件。如果手机没有弹出保存提示，请改用浏览器打开网页导出。');
    }catch(e){tell('备份失败：'+String(e.message||e));}
  };
  $('import').onclick=()=>{$('file').click();};
  $('file').onchange=async e=>{
    const file=e.target.files&&e.target.files[0];if(!file)return;
    try{
      if(file.size>2*1024*1024)throw Error('备份文件过大');
      const b=JSON.parse(await file.text());
      if(b.type!=='linguago-learning-backup'||!b.progress||!Array.isArray(b.progress.known))throw Error('不是有效的 LinguaGo 备份');
      if(!confirm('将备份中的记录与当前记录合并，再自动同步到当前登录账号。确认继续吗？'))return;
      const current=app.snapshot();const data=merge(current,b.progress,null);
      app.restore(data);if(session) await synchronize();
      tell('已恢复并合并备份记录。'+(session?'如网络正常，将继续同步。':'登录后可上传云端。'));
    }catch(err){tell('恢复失败：'+String(err.message||err));}
    finally{$('file').value='';}
  };
  $('login').onclick = () => authenticate(false);
  $('register').onclick = () => authenticate(true);
  $('sync').onclick = () => synchronize();
  $('logout').onclick = async () => {
    if (!confirm('退出账号将停止自动同步，但本机记录仍会保留。确定吗？')) return;
    try { await call('/auth/v1/logout', 'POST'); } catch (_) {}
    storeSession(null); tell('已退出，学习记录仍保留在本机。');
  };
  addEventListener('online', () => { if (session) synchronize(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && session) synchronize(); });
  if (configured) {
    const prior = parseJson(SESSION_KEY);
    if (prior && prior.access_token && prior.user && prior.user.id) { session = prior; synchronize(); }
  }
  draw();
})();
