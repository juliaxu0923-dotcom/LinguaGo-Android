window.LINGUAGO_CLOUD={"url": "https://dfgkfvqqrinrgfvhuczm.supabase.co", "key": "sb_publishable_jkFVNbsy1Z3XIhJsQElRMw_LwxNTcak"};
